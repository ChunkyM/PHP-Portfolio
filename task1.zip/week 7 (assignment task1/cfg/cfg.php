<?php
$cfg['db']['host']= 'fcet7.staffs.ac.uk';
$cfg['db']['user']= 'm026540e';
$cfg['db']['pass']= 'm026540e';
$cfg['db']['db']= 'm026540e';
